package com.example.reagain;

public class Storage {
    public static String token;

}
